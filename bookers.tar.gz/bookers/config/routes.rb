Rails.application.routes.draw do
  root :to =>'homes#top'
  resources :homes
  resources :books
  #delete 'books/:id' => 'books#destroy', as: 'destroy_books'
  # get 'homes/index'
  # get 'homes/show'
  # get 'homes/new'
  # get 'homes/edit'
  # get 'books/index'
  # get 'books/show'
  # get 'books/new'
  # get 'books/edit'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
